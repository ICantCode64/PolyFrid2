const http = require("http");
const crypto = require("crypto");
const fs = require("fs");

const PORT = 3000;

const PRIVATE_KEY_PEM = `
-----BEGIN PRIVATE KEY-----
MIGHAgEAMBMGByqGSM49AgEGCCqGSM49AwEHBG0wawIBAQQgo7JeB1P3UWqL7Gs3
dE4Tv9f0tVsD9zYb55snLvEgizuhRANCAASBrzp91SpKZzHT3PnO21S+2esohLsQ
mq+7UfUeyL1C1ZxpB/dqR8LQ6o73WpLfAzrFduM0cLZa5LGzkO9FHSnU
-----END PRIVATE KEY-----
`;

function signResponse(status, nonce) {
    const msg =
        "status=" + status + "\n" +
        "nonce=" + nonce;

    return crypto.sign("sha256", Buffer.from(msg), {
        key: PRIVATE_KEY_PEM,
        dsaEncoding: "ieee-p1363"
    }).toString("base64");
}

function sendJson(res, code, data) {
    const body = JSON.stringify(data);

    res.writeHead(code, {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(body)
    });

    res.end(body);
}

function readBody(req) {
    return new Promise((resolve, reject) => {
        let body = "";

        req.on("data", chunk => {
            body += chunk;

            if (body.length > 4096)
                req.destroy();
        });

        req.on("end", () => resolve(body));
        req.on("error", reject);
    });
}

function loadKeys() {
    try {
        const raw = fs.readFileSync("./keys.json", "utf8");
        const keys = JSON.parse(raw);

        if (!Array.isArray(keys))
            return [];

        return keys;
    } catch {
        return [];
    }
}

function isExpired(expireOn) {
    if (typeof expireOn !== "string")
        return true;

    const expireTime = Date.parse(expireOn);

    if (Number.isNaN(expireTime))
        return true;

    return Date.now() > expireTime;
}

function verifyUserKey(username, key) {
    const keys = loadKeys();

    const found = keys.find(entry =>
        entry.username === username &&
        entry.key === key
    );

    if (!found)
        return false;

    if (found.active !== true)
        return false;

    if (isExpired(found.expire_on))
        return false;

    return true;
}

const server = http.createServer(async (req, res) => {
    if (req.method !== "POST" || req.url !== "/api/verify") {
        const status = "invalid";
        const nonce = "";

        return sendJson(res, 404, {
            status,
            nonce,
            signature: signResponse(status, nonce)
        });
    }

    try {
        const raw = await readBody(req);
        const data = JSON.parse(raw);

        const username = data.username;
        const key = data.key;
        const nonce = data.nonce;

        let status = "invalid";

        if (
            typeof username === "string" &&
            typeof key === "string" &&
            typeof nonce === "string" &&
            nonce.length >= 16 &&
            nonce.length <= 128
        ) {
            if (verifyUserKey(username, key))
                status = "valid";
        }

        const safeNonce = typeof nonce === "string" ? nonce : "";

        return sendJson(res, 200, {
            status,
            nonce: safeNonce,
            signature: signResponse(status, safeNonce)
        });
    } catch {
        const status = "invalid";
        const nonce = "";

        return sendJson(res, 200, {
            status,
            nonce,
            signature: signResponse(status, nonce)
        });
    }
});

server.listen(PORT, () => {
    console.log("Key server running on port " + PORT);
});