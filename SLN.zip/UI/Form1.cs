﻿
using Microsoft.Win32;
using System;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace UI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (NamedPipeClientStream pipeClient =
        new NamedPipeClientStream(".", "PolyFrid2", PipeDirection.Out))
            {
                pipeClient.Connect();

                byte[] buffer = Encoding.UTF8.GetBytes(fastColoredTextBox1.Text);
                pipeClient.Write(buffer, 0, buffer.Length);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string fullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "bin", "PolyFrid2.dll");
            Process p = Process.GetProcessesByName("Polytoria Client")[0];
            if (p != null)
            {
                Injector.InjectDll(p.Id, fullPath);
            } else
            {
                MessageBox.Show("Please launch polytoria before injecting.", "PolyFrid");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string dir = Path.Combine(Application.StartupPath, "scripts");
            Directory.CreateDirectory(dir);

            listBox1.Items.Clear();
            listBox1.Items.AddRange(
                Directory.GetFiles(dir, "*.lua")
                .Select(Path.GetFileNameWithoutExtension)
                .ToArray()
            );
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
                return;

            string selection = listBox1.SelectedItem.ToString();

            string path = Path.Combine("scripts", selection + ".lua");

            if (File.Exists(path))
            {
                fastColoredTextBox1.Text = File.ReadAllText(path);
            }
            else
            {
                MessageBox.Show("File not found: " + path, "PolyFrid");
                string dir = Path.Combine(Application.StartupPath, "scripts");
                Directory.CreateDirectory(dir);

                listBox1.Items.Clear();
                listBox1.Items.AddRange(
                    Directory.GetFiles(dir, "*.lua")
                    .Select(Path.GetFileNameWithoutExtension)
                    .ToArray()
                );
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Lua files (*.lua)|*.lua|All files (*.*)|*.*";
                dlg.DefaultExt = "lua";
                dlg.InitialDirectory = Path.Combine(Application.StartupPath, "scripts");

                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    File.WriteAllText(dlg.FileName, fastColoredTextBox1.Text);
                }
            }

            string dir = Path.Combine(Application.StartupPath, "scripts");
            Directory.CreateDirectory(dir);

            listBox1.Items.Clear();
            listBox1.Items.AddRange(
                Directory.GetFiles(dir, "*.lua")
                .Select(Path.GetFileNameWithoutExtension)
                .ToArray()
            );
        }
    }
}
