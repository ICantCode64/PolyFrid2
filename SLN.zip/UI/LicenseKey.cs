﻿using Microsoft.Win32;
using System;
using System.Net;
using System.Windows.Forms;

namespace UI
{
    public partial class LicenseKey : Form
    {
        public LicenseKey()
        {
            InitializeComponent();
        }

        static string JsonEscape(string s)
        {
            if (s == null) return "";

            return s
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", "\\r")
                .Replace("\n", "\\n")
                .Replace("\t", "\\t");
        }

        static string JsonGet(string json, string name)
        {
            string find = "\"" + name + "\":\"";
            int start = json.IndexOf(find);

            if (start < 0)
                return "";

            start += find.Length;

            int end = json.IndexOf("\"", start);

            if (end < 0)
                return "";

            return json.Substring(start, end - start);
        }

        bool CheckKeyWeb(string Name, string key)
        {
            string nonce = Guid.NewGuid().ToString("N");

            string json =
                "{"
                + "\"username\":\"" + JsonEscape(Name) + "\","
                + "\"key\":\"" + JsonEscape(key) + "\","
                + "\"nonce\":\"" + nonce + "\""
                + "}";

            try
            {
                using (WebClient wc = new WebClient())
                {
                    wc.Headers[HttpRequestHeader.ContentType] = "application/json";

                    string response = wc.UploadString(
                        "http://127.0.0.1:3000/api/verify",
                        "POST",
                        json
                    );

                    string status = JsonGet(response, "status");
                    string returnedNonce = JsonGet(response, "nonce");

                    return status == "valid" && returnedNonce == nonce;
                }
            }
            catch
            {
                return false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string licenseKey = textBox2.Text;

            if (!CheckKeyWeb(name, licenseKey))
            {
                MessageBox.Show("Incorrect key.", "PolyFrid");
                return;
            }

            using (RegistryKey reg = Registry.CurrentUser.CreateSubKey(@"Software\PolyFrid\License"))
            {
                if (reg != null)
                {
                    reg.SetValue("Name", name);
                    reg.SetValue("Key", licenseKey);
                }
            }

            MessageBox.Show("License key activated!", "PolyFrid");

            Form1 form = new Form1();
            this.Hide();
            form.Show();
        }

        private void LicenseKey_Load(object sender, EventArgs e)
        {
            using (RegistryKey reg = Registry.CurrentUser.OpenSubKey(@"Software\PolyFrid\License"))
            {
                string savedName = reg?.GetValue("Name") as string;
                string savedKey = reg?.GetValue("Key") as string;

                if (!string.IsNullOrEmpty(savedName) &&
                    !string.IsNullOrEmpty(savedKey) &&
                    CheckKeyWeb(savedName, savedKey))
                {
                    this.BeginInvoke(new Action(() =>
                    {
                        Form1 s = new Form1();
                        this.Hide();
                        s.Show();
                    }));
                }
            }
        }
    }
}
