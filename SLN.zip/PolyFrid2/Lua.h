#pragma once
#include <Windows.h>
#include <string>
#include "Libraries/Helpers.h"

#define LUA_GLOBALSINDEX   (-10002)
#define LUA_REGISTRYINDEX  (-10000)

#define LUA_TNIL          0
#define LUA_TBOOLEAN      1
#define LUA_TLIGHTUSERDATA 2
#define LUA_TNUMBER       3
#define LUA_TSTRING       4
#define LUA_TTABLE        5
#define LUA_TFUNCTION     6
#define LUA_TUSERDATA     7
#define LUA_TTHREAD       8

#define LUA_MULTRET (-1)

struct lua_State;
typedef int(*lua_CFunction)(lua_State* L);

using lua_gettop_t = int(__fastcall*)(lua_State* L);
typedef int(__fastcall* luau_load_t)(
    lua_State* L,
    const char* chunkname,
    void* bytecode,
    int size,
    void* env,
    void* ctx1,
    void* ctx2,
    void* ctx3,
    int flags
    );

typedef void* (__fastcall* luau_compile_t)(
    void* Src,
    size_t Size,
    void* Options,
    void* Out
    );

typedef __int64(__fastcall* lua_pcall_t)(
    lua_State* L,
    int nargs,
    int nresults,
    int errfunc
    );

inline lua_gettop_t fp_lua_gettop = nullptr;
inline luau_load_t fp_luau_load = nullptr;
inline luau_compile_t fp_luau_compile = nullptr;
inline lua_pcall_t fp_lua_pcall = nullptr;

inline void GetFunctions()
{
    HMODULE hMod_VM = GetModuleHandleA("Luau.VM.dll");
    if (!hMod_VM)
        return;

    HMODULE hMod_Compiler = GetModuleHandleA("Luau.Compiler.dll");
    if (!hMod_Compiler)
        return;

    fp_luau_load =
        (luau_load_t)GetProcAddress(hMod_VM, "luau_load");

    fp_luau_compile =
        (luau_compile_t)GetProcAddress(hMod_Compiler, "luau_compile");

    fp_lua_pcall =
        (lua_pcall_t)GetProcAddress(hMod_VM, "lua_pcall");

    fp_lua_gettop = 
        (lua_gettop_t)GetProcAddress(hMod_VM, "lua_gettop");
}

inline int CompileString(lua_State* L, const std::string& code) {
    if (!L || !fp_luau_compile || !fp_luau_load)
        return 1;

    uint8_t out[8] = {};

    void* bytecode = fp_luau_compile(
        (void*)code.c_str(),
        code.size(),
        nullptr,
        out
    );

    if (!bytecode)
        return 1;

    uint32_t size = *(uint32_t*)out;

    int status = fp_luau_load(
        L,
        "chunk",
        bytecode,
        size,
        nullptr,
        nullptr,
        nullptr,
        nullptr,
        0
    );

    return status;
}

inline void Exec(lua_State* L, const std::string& code)
{
    int status = CompileString(L, code);
    if (status == 0)
    {
        fp_lua_pcall(L, 0, 0, 0);
    }
    else {
        Log("[-] Compile failed");
    }
}