#pragma once

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _WINSOCKAPI_

#include <windows.h>
#include <winhttp.h>

#include <string>
#include <iostream>

typedef HINTERNET(WINAPI* WinHttpOpen_t)(
    LPCWSTR, DWORD, LPCWSTR, LPCWSTR, DWORD);

typedef HINTERNET(WINAPI* WinHttpConnect_t)(
    HINTERNET, LPCWSTR, INTERNET_PORT, DWORD);

typedef HINTERNET(WINAPI* WinHttpOpenRequest_t)(
    HINTERNET,
    LPCWSTR,
    LPCWSTR,
    LPCWSTR,
    LPCWSTR,
    LPCWSTR*,
    DWORD);

typedef BOOL(WINAPI* WinHttpSendRequest_t)(
    HINTERNET,
    LPCWSTR,
    DWORD,
    LPVOID,
    DWORD,
    DWORD,
    DWORD_PTR);

typedef BOOL(WINAPI* WinHttpReceiveResponse_t)(
    HINTERNET,
    LPVOID);

typedef BOOL(WINAPI* WinHttpQueryDataAvailable_t)(
    HINTERNET,
    LPDWORD);

typedef BOOL(WINAPI* WinHttpReadData_t)(
    HINTERNET,
    LPVOID,
    DWORD,
    LPDWORD);

typedef BOOL(WINAPI* WinHttpCloseHandle_t)(
    HINTERNET);

static HMODULE hWinHttp = nullptr;

static WinHttpOpen_t pWinHttpOpen = nullptr;
static WinHttpConnect_t pWinHttpConnect = nullptr;
static WinHttpOpenRequest_t pWinHttpOpenRequest = nullptr;
static WinHttpSendRequest_t pWinHttpSendRequest = nullptr;
static WinHttpReceiveResponse_t pWinHttpReceiveResponse = nullptr;
static WinHttpQueryDataAvailable_t pWinHttpQueryDataAvailable = nullptr;
static WinHttpReadData_t pWinHttpReadData = nullptr;
static WinHttpCloseHandle_t pWinHttpCloseHandle = nullptr;

bool InitHttp()
{
    hWinHttp = LoadLibraryA("winhttp.dll");

    if (!hWinHttp)
        return false;

    pWinHttpOpen =
        (WinHttpOpen_t)GetProcAddress(hWinHttp, "WinHttpOpen");

    pWinHttpConnect =
        (WinHttpConnect_t)GetProcAddress(hWinHttp, "WinHttpConnect");

    pWinHttpOpenRequest =
        (WinHttpOpenRequest_t)GetProcAddress(hWinHttp, "WinHttpOpenRequest");

    pWinHttpSendRequest =
        (WinHttpSendRequest_t)GetProcAddress(hWinHttp, "WinHttpSendRequest");

    pWinHttpReceiveResponse =
        (WinHttpReceiveResponse_t)GetProcAddress(hWinHttp, "WinHttpReceiveResponse");

    pWinHttpQueryDataAvailable =
        (WinHttpQueryDataAvailable_t)GetProcAddress(hWinHttp, "WinHttpQueryDataAvailable");

    pWinHttpReadData =
        (WinHttpReadData_t)GetProcAddress(hWinHttp, "WinHttpReadData");

    pWinHttpCloseHandle =
        (WinHttpCloseHandle_t)GetProcAddress(hWinHttp, "WinHttpCloseHandle");

    return
        pWinHttpOpen &&
        pWinHttpConnect &&
        pWinHttpOpenRequest &&
        pWinHttpSendRequest &&
        pWinHttpReceiveResponse &&
        pWinHttpQueryDataAvailable &&
        pWinHttpReadData &&
        pWinHttpCloseHandle;
}

void ShutdownHttp()
{
    if (hWinHttp)
    {
        FreeLibrary(hWinHttp);
        hWinHttp = nullptr;
    }
}

bool ParseURL(
    const std::string& url,
    std::wstring& host,
    std::wstring& path,
    bool& https)
{
    https = false;

    std::string temp = url;

    if (temp.rfind("https://", 0) == 0)
    {
        https = true;
        temp.erase(0, 8);
    }
    else if (temp.rfind("http://", 0) == 0)
    {
        temp.erase(0, 7);
    }

    size_t slash = temp.find('/');

    std::string hostStr;
    std::string pathStr;

    if (slash == std::string::npos)
    {
        hostStr = temp;
        pathStr = "/";
    }
    else
    {
        hostStr = temp.substr(0, slash);
        pathStr = temp.substr(slash);
    }

    host = std::wstring(
        hostStr.begin(),
        hostStr.end());

    path = std::wstring(
        pathStr.begin(),
        pathStr.end());

    return true;
}

std::string HTTPGET(
    const wchar_t* host,
    const wchar_t* path)
{
    std::string result;

    HINTERNET hSession = pWinHttpOpen(
        L"PolyFrid2/1.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0
    );

    if (!hSession)
        return result;

    HINTERNET hConnect = pWinHttpConnect(
        hSession,
        host,
        INTERNET_DEFAULT_HTTPS_PORT,
        0
    );

    if (!hConnect)
    {
        pWinHttpCloseHandle(hSession);
        return result;
    }

    HINTERNET hRequest = pWinHttpOpenRequest(
        hConnect,
        L"GET",
        path,
        NULL,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        WINHTTP_FLAG_SECURE
    );

    if (!hRequest)
    {
        pWinHttpCloseHandle(hConnect);
        pWinHttpCloseHandle(hSession);
        return result;
    }

    if (!pWinHttpSendRequest(
        hRequest,
        WINHTTP_NO_ADDITIONAL_HEADERS,
        0,
        WINHTTP_NO_REQUEST_DATA,
        0,
        0,
        0))
    {
        return result;
    }

    if (!pWinHttpReceiveResponse(hRequest, NULL))
    {
        return result;
    }

    DWORD size = 0;

    do
    {
        DWORD downloaded = 0;

        if (!pWinHttpQueryDataAvailable(hRequest, &size))
            break;

        if (size == 0)
            break;

        std::string buffer;
        buffer.resize(size);

        if (!pWinHttpReadData(
            hRequest,
            buffer.data(),
            size,
            &downloaded))
        {
            break;
        }

        result.append(buffer.c_str(), downloaded);

    } while (size > 0);

    pWinHttpCloseHandle(hRequest);
    pWinHttpCloseHandle(hConnect);
    pWinHttpCloseHandle(hSession);

    return result;
}

std::string HTTPPOST(
    const wchar_t* host,
    INTERNET_PORT port,
    const wchar_t* path,
    const std::string& body,
    bool secure)
{
    std::string result;

    HINTERNET hSession = pWinHttpOpen(
        L"PolyFrid2/1.0",
        WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0
    );

    if (!hSession)
        return result;

    HINTERNET hConnect = pWinHttpConnect(
        hSession,
        host,
        port,
        0
    );

    if (!hConnect)
    {
        pWinHttpCloseHandle(hSession);
        return result;
    }

    DWORD flags = secure ? WINHTTP_FLAG_SECURE : 0;

    HINTERNET hRequest = pWinHttpOpenRequest(
        hConnect,
        L"POST",
        path,
        NULL,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        flags
    );

    if (!hRequest)
    {
        pWinHttpCloseHandle(hConnect);
        pWinHttpCloseHandle(hSession);
        return result;
    }

    const wchar_t* headers =
        L"Content-Type: application/json\r\n"
        L"Accept: application/json\r\n";

    DWORD bodySize = (DWORD)body.size();

    BOOL sent = pWinHttpSendRequest(
        hRequest,
        headers,
        (DWORD)-1L,
        (LPVOID)body.data(),
        bodySize,
        bodySize,
        0
    );

    if (!sent)
    {
        pWinHttpCloseHandle(hRequest);
        pWinHttpCloseHandle(hConnect);
        pWinHttpCloseHandle(hSession);
        return result;
    }

    if (!pWinHttpReceiveResponse(hRequest, NULL))
    {
        pWinHttpCloseHandle(hRequest);
        pWinHttpCloseHandle(hConnect);
        pWinHttpCloseHandle(hSession);
        return result;
    }

    DWORD size = 0;

    do
    {
        DWORD downloaded = 0;

        if (!pWinHttpQueryDataAvailable(hRequest, &size))
            break;

        if (size == 0)
            break;

        std::string buffer;
        buffer.resize(size);

        if (!pWinHttpReadData(
            hRequest,
            buffer.data(),
            size,
            &downloaded))
        {
            break;
        }

        result.append(buffer.data(), downloaded);

    } while (size > 0);

    pWinHttpCloseHandle(hRequest);
    pWinHttpCloseHandle(hConnect);
    pWinHttpCloseHandle(hSession);

    return result;
}