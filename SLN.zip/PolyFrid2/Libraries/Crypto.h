#pragma once

#include <windows.h>
#include <bcrypt.h>
#include <wincrypt.h>

#include <string>
#include <vector>

typedef NTSTATUS(WINAPI* BCryptOpenAlgorithmProvider_t)(
    BCRYPT_ALG_HANDLE*, LPCWSTR, LPCWSTR, ULONG);

typedef NTSTATUS(WINAPI* BCryptCloseAlgorithmProvider_t)(
    BCRYPT_ALG_HANDLE, ULONG);

typedef NTSTATUS(WINAPI* BCryptCreateHash_t)(
    BCRYPT_ALG_HANDLE, BCRYPT_HASH_HANDLE*, PUCHAR, ULONG, PUCHAR, ULONG, ULONG);

typedef NTSTATUS(WINAPI* BCryptHashData_t)(
    BCRYPT_HASH_HANDLE, PUCHAR, ULONG, ULONG);

typedef NTSTATUS(WINAPI* BCryptFinishHash_t)(
    BCRYPT_HASH_HANDLE, PUCHAR, ULONG, ULONG);

typedef NTSTATUS(WINAPI* BCryptDestroyHash_t)(
    BCRYPT_HASH_HANDLE);

typedef NTSTATUS(WINAPI* BCryptImportKeyPair_t)(
    BCRYPT_ALG_HANDLE, BCRYPT_KEY_HANDLE, LPCWSTR, BCRYPT_KEY_HANDLE*, PUCHAR, ULONG, ULONG);

typedef NTSTATUS(WINAPI* BCryptDestroyKey_t)(
    BCRYPT_KEY_HANDLE);

typedef NTSTATUS(WINAPI* BCryptVerifySignature_t)(
    BCRYPT_KEY_HANDLE, VOID*, PUCHAR, ULONG, PUCHAR, ULONG, ULONG);

typedef BOOL(WINAPI* CryptStringToBinaryA_t)(
    LPCSTR, DWORD, DWORD, BYTE*, DWORD*, DWORD*, DWORD*);

typedef NTSTATUS(WINAPI* BCryptGenRandom_t)(
    BCRYPT_ALG_HANDLE, PUCHAR, ULONG, ULONG);

static HMODULE hBcrypt = nullptr;
static HMODULE hCrypt32 = nullptr;

static BCryptOpenAlgorithmProvider_t pBCryptOpenAlgorithmProvider = nullptr;
static BCryptCloseAlgorithmProvider_t pBCryptCloseAlgorithmProvider = nullptr;
static BCryptCreateHash_t pBCryptCreateHash = nullptr;
static BCryptHashData_t pBCryptHashData = nullptr;
static BCryptFinishHash_t pBCryptFinishHash = nullptr;
static BCryptDestroyHash_t pBCryptDestroyHash = nullptr;
static BCryptImportKeyPair_t pBCryptImportKeyPair = nullptr;
static BCryptDestroyKey_t pBCryptDestroyKey = nullptr;
static BCryptVerifySignature_t pBCryptVerifySignature = nullptr;
static CryptStringToBinaryA_t pCryptStringToBinaryA = nullptr;
static BCryptGenRandom_t pBCryptGenRandom = nullptr;

bool InitCrypto()
{
    hBcrypt = LoadLibraryA("bcrypt.dll");
    hCrypt32 = LoadLibraryA("crypt32.dll");

    if (!hBcrypt || !hCrypt32)
        return false;

    pBCryptOpenAlgorithmProvider =
        (BCryptOpenAlgorithmProvider_t)GetProcAddress(hBcrypt, "BCryptOpenAlgorithmProvider");

    pBCryptCloseAlgorithmProvider =
        (BCryptCloseAlgorithmProvider_t)GetProcAddress(hBcrypt, "BCryptCloseAlgorithmProvider");

    pBCryptCreateHash =
        (BCryptCreateHash_t)GetProcAddress(hBcrypt, "BCryptCreateHash");

    pBCryptHashData =
        (BCryptHashData_t)GetProcAddress(hBcrypt, "BCryptHashData");

    pBCryptFinishHash =
        (BCryptFinishHash_t)GetProcAddress(hBcrypt, "BCryptFinishHash");

    pBCryptDestroyHash =
        (BCryptDestroyHash_t)GetProcAddress(hBcrypt, "BCryptDestroyHash");

    pBCryptImportKeyPair =
        (BCryptImportKeyPair_t)GetProcAddress(hBcrypt, "BCryptImportKeyPair");

    pBCryptDestroyKey =
        (BCryptDestroyKey_t)GetProcAddress(hBcrypt, "BCryptDestroyKey");

    pBCryptVerifySignature =
        (BCryptVerifySignature_t)GetProcAddress(hBcrypt, "BCryptVerifySignature");

    pCryptStringToBinaryA =
        (CryptStringToBinaryA_t)GetProcAddress(hCrypt32, "CryptStringToBinaryA");

    pBCryptGenRandom =
        (BCryptGenRandom_t)GetProcAddress(hBcrypt, "BCryptGenRandom");

    return
        pBCryptOpenAlgorithmProvider &&
        pBCryptCloseAlgorithmProvider &&
        pBCryptCreateHash &&
        pBCryptHashData &&
        pBCryptFinishHash &&
        pBCryptDestroyHash &&
        pBCryptImportKeyPair &&
        pBCryptDestroyKey &&
        pBCryptVerifySignature &&
        pCryptStringToBinaryA &&
        pBCryptGenRandom;
}

void ShutdownCrypto()
{
    if (hBcrypt)
    {
        FreeLibrary(hBcrypt);
        hBcrypt = nullptr;
    }

    if (hCrypt32)
    {
        FreeLibrary(hCrypt32);
        hCrypt32 = nullptr;
    }
}

std::string JsonGetString(const std::string& json, const std::string& key)
{
    std::string find = "\"" + key + "\":\"";
    size_t start = json.find(find);

    if (start == std::string::npos)
        return "";

    start += find.size();

    size_t end = json.find("\"", start);

    if (end == std::string::npos)
        return "";

    return json.substr(start, end - start);
}

inline std::string JsonEscape(const std::string& s)
{
    std::string out;

    for (char c : s)
    {
        if (c == '\\') out += "\\\\";
        else if (c == '"') out += "\\\"";
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else out += c;
    }

    return out;
}

inline std::string GenerateNonce()
{
    unsigned char bytes[16];

    if (!pBCryptGenRandom)
        return "";

    if (pBCryptGenRandom(
        nullptr,
        bytes,
        sizeof(bytes),
        BCRYPT_USE_SYSTEM_PREFERRED_RNG) < 0)
    {
        return "";
    }

    static const char hex[] = "0123456789abcdef";

    std::string out;
    out.reserve(32);

    for (int i = 0; i < 16; i++)
    {
        out += hex[(bytes[i] >> 4) & 0xF];
        out += hex[bytes[i] & 0xF];
    }

    return out;
}

bool Base64Decode(const std::string& input, std::vector<unsigned char>& output)
{
    DWORD size = 0;

    if (!pCryptStringToBinaryA(
        input.c_str(),
        0,
        CRYPT_STRING_BASE64,
        nullptr,
        &size,
        nullptr,
        nullptr))
    {
        return false;
    }

    output.resize(size);

    if (!pCryptStringToBinaryA(
        input.c_str(),
        0,
        CRYPT_STRING_BASE64,
        output.data(),
        &size,
        nullptr,
        nullptr))
    {
        return false;
    }

    output.resize(size);
    return true;
}

bool Sha256(const std::string& data, unsigned char outHash[32])
{
    BCRYPT_ALG_HANDLE hAlg = nullptr;
    BCRYPT_HASH_HANDLE hHash = nullptr;

    if (pBCryptOpenAlgorithmProvider(
        &hAlg,
        BCRYPT_SHA256_ALGORITHM,
        nullptr,
        0) < 0)
    {
        return false;
    }

    if (pBCryptCreateHash(
        hAlg,
        &hHash,
        nullptr,
        0,
        nullptr,
        0,
        0) < 0)
    {
        pBCryptCloseAlgorithmProvider(hAlg, 0);
        return false;
    }

    bool ok = false;

    if (pBCryptHashData(
        hHash,
        (PUCHAR)data.data(),
        (ULONG)data.size(),
        0) >= 0)
    {
        if (pBCryptFinishHash(hHash, outHash, 32, 0) >= 0)
            ok = true;
    }

    pBCryptDestroyHash(hHash);
    pBCryptCloseAlgorithmProvider(hAlg, 0);

    return ok;
}