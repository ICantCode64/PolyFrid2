#pragma once

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _WINSOCKAPI_

#include <windows.h>

static HANDLE g_console = nullptr;

inline void ResetConsoleColor()
{
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
}

inline void LogEx(bool newline, const char* fmt, ...)
{
    if (!g_console) return;

    char buffer[2048];

    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    wchar_t wbuffer[2048];

    MultiByteToWideChar(
        CP_UTF8,
        0,
        buffer,
        -1,
        wbuffer,
        2048
    );

    DWORD written;
    WriteConsoleW(
        g_console,
        wbuffer,
        lstrlenW(wbuffer),
        &written,
        nullptr
    );

    if (newline)
    {
        const wchar_t nl[] = L"\r\n";
        WriteConsoleW(g_console, nl, 2, &written, nullptr);
    }
}

inline void Log(const char* fmt, ...)
{
    if (!g_console) return;

    char buffer[2048];

    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    wchar_t wbuffer[2048];

    MultiByteToWideChar(
        CP_UTF8,
        0,
        buffer,
        -1,
        wbuffer,
        2048
    );

    DWORD written;
    WriteConsoleW(g_console, wbuffer, lstrlenW(wbuffer), &written, nullptr);

    const wchar_t nl[] = L"\r\n";
    WriteConsoleW(g_console, nl, 2, &written, nullptr);
}

inline void LogInline(const char* fmt, ...)
{
    if (!g_console) return;

    char buffer[2048];

    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    wchar_t wbuffer[2048];

    MultiByteToWideChar(
        CP_UTF8,
        0,
        buffer,
        -1,
        wbuffer,
        2048
    );

    DWORD written;
    WriteConsoleW(g_console, wbuffer, lstrlenW(wbuffer), &written, nullptr);
}

inline void InitConsole()
{
    AllocConsole();
    SetConsoleTitleA("PolyFrid2 [BETA]");

    g_console = CreateFileA(
        "CONOUT$",
        GENERIC_WRITE,
        FILE_SHARE_WRITE,
        nullptr,
        OPEN_EXISTING,
        0,
        nullptr
    );

    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
}

inline std::string Input(const char* prompt)
{
    if (!g_console) return "";

    char buffer[1024];
    DWORD read;

    DWORD written;
    WriteConsoleA(g_console, prompt, strlen(prompt), &written, nullptr);

    HANDLE hIn = CreateFileA(
        "CONIN$",
        GENERIC_READ,
        FILE_SHARE_READ,
        nullptr,
        OPEN_EXISTING,
        0,
        nullptr
    );

    ReadConsoleA(hIn, buffer, sizeof(buffer), &read, nullptr);
    CloseHandle(hIn);

    if (read > 0 &&
        (buffer[read - 1] == '\n' || buffer[read - 1] == '\r'))
    {
        buffer[read - 1] = 0;
    }

    return std::string(buffer);
}

inline bool IsValidMemory(uintptr_t ptr)
{
    if (!ptr)
        return false;

    MEMORY_BASIC_INFORMATION mbi{};
    SIZE_T result = VirtualQuery(
        reinterpret_cast<LPCVOID>(ptr),
        &mbi,
        sizeof(mbi)
    );

    if (result == 0)
        return false;

    if (mbi.State != MEM_COMMIT)
        return false;

    if (mbi.Protect & PAGE_GUARD)
        return false;

    if (mbi.Protect & (PAGE_NOACCESS))
        return false;

    return true;
}

std::string ReadRegistryString(HKEY root, const std::string& subKey, const std::string& valueName)
{
    HKEY hKey;
    char buffer[256];
    DWORD size = sizeof(buffer);

    if (RegOpenKeyExA(root, subKey.c_str(), 0, KEY_READ, &hKey) != ERROR_SUCCESS)
        return "";

    if (RegQueryValueExA(hKey, valueName.c_str(), nullptr, nullptr, (LPBYTE)buffer, &size) != ERROR_SUCCESS)
    {
        RegCloseKey(hKey);
        return "";
    }

    RegCloseKey(hKey);
    return std::string(buffer);
}

static void send_mouse(DWORD flags) {
    INPUT input;
    ZeroMemory(&input, sizeof(input));

    input.type = INPUT_MOUSE;
    input.mi.dwFlags = flags;

    SendInput(1, &input, sizeof(INPUT));
}

static void send_key(WORD key, DWORD flags) {
    INPUT input;
    ZeroMemory(&input, sizeof(input));

    input.type = INPUT_KEYBOARD;
    input.ki.wVk = key;
    input.ki.dwFlags = flags;

    SendInput(1, &input, sizeof(INPUT));
}