#pragma once

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _WINSOCKAPI_

#include <string>
#include <vector>
#include "Libraries/Crypto.h"
#include "Libraries/Http.h"

namespace KeySystem
{
    static const unsigned char SERVER_PUBLIC_KEY_X[32] =
    {
        0x81, 0xaf, 0x3a, 0x7d, 0xd5, 0x2a, 0x4a, 0x67, 0x31, 0xd3, 0xdc, 0xf9, 0xce, 0xdb, 0x54, 0xbe, 0xd9, 0xeb, 0x28, 0x84, 0xbb, 0x10, 0x9a, 0xaf, 0xbb, 0x51, 0xf5, 0x1e, 0xc8, 0xbd, 0x42, 0xd5
    };

    static const unsigned char SERVER_PUBLIC_KEY_Y[32] =
    {
        0x9c, 0x69, 0x07, 0xf7, 0x6a, 0x47, 0xc2, 0xd0, 0xea, 0x8e, 0xf7, 0x5a, 0x92, 0xdf, 0x03, 0x3a, 0xc5, 0x76, 0xe3, 0x34, 0x70, 0xb6, 0x5a, 0xe4, 0xb1, 0xb3, 0x90, 0xef, 0x45, 0x1d, 0x29, 0xd4
    };

    inline bool VerifyServerResponse(
        const std::string& responseJson,
        const std::string& expectedNonce)
    {
        std::string status = JsonGetString(responseJson, "status");
        std::string nonce = JsonGetString(responseJson, "nonce");
        std::string signatureBase64 = JsonGetString(responseJson, "signature");

        if (status.empty() || nonce.empty() || signatureBase64.empty())
            return false;

        if (nonce != expectedNonce)
            return false;

        if (status != "valid" && status != "invalid")
            return false;

        std::string signedMessage =
            "status=" + status + "\n" +
            "nonce=" + nonce;

        unsigned char hash[32];

        if (!Sha256(signedMessage, hash))
            return false;

        std::vector<unsigned char> signature;

        if (!Base64Decode(signatureBase64, signature))
            return false;

        if (signature.size() != 64)
            return false;

        BCRYPT_ALG_HANDLE hAlg = nullptr;
        BCRYPT_KEY_HANDLE hKey = nullptr;

        if (pBCryptOpenAlgorithmProvider(
            &hAlg,
            BCRYPT_ECDSA_P256_ALGORITHM,
            nullptr,
            0) < 0)
        {
            return false;
        }

        std::vector<unsigned char> keyBlob;
        keyBlob.resize(sizeof(BCRYPT_ECCKEY_BLOB) + 64);

        BCRYPT_ECCKEY_BLOB* header =
            (BCRYPT_ECCKEY_BLOB*)keyBlob.data();

        header->dwMagic = BCRYPT_ECDSA_PUBLIC_P256_MAGIC;
        header->cbKey = 32;

        memcpy(
            keyBlob.data() + sizeof(BCRYPT_ECCKEY_BLOB),
            SERVER_PUBLIC_KEY_X,
            32
        );

        memcpy(
            keyBlob.data() + sizeof(BCRYPT_ECCKEY_BLOB) + 32,
            SERVER_PUBLIC_KEY_Y,
            32
        );

        bool ok = false;

        if (pBCryptImportKeyPair(
            hAlg,
            nullptr,
            BCRYPT_ECCPUBLIC_BLOB,
            &hKey,
            keyBlob.data(),
            (ULONG)keyBlob.size(),
            0) >= 0)
        {
            if (pBCryptVerifySignature(
                hKey,
                nullptr,
                hash,
                32,
                signature.data(),
                (ULONG)signature.size(),
                0) >= 0)
            {
                ok = true;
            }

            pBCryptDestroyKey(hKey);
        }

        pBCryptCloseAlgorithmProvider(hAlg, 0);

        return ok;
    }

    inline bool verify(const std::string& username, const std::string& key)
    {
        if (!InitHttp())
            return false;

        if (!InitCrypto())
        {
            ShutdownHttp();
            return false;
        }

        bool finalResult = false;

        std::string nonce = GenerateNonce();

        if (!nonce.empty())
        {
            std::string body =
                "{"
                "\"username\":\"" + JsonEscape(username) + "\","
                "\"key\":\"" + JsonEscape(key) + "\","
                "\"nonce\":\"" + nonce + "\""
                "}";

            std::string response = HTTPPOST(
                L"127.0.0.1",
                3000,
                L"/api/verify",
                body,
                false
            );

            if (VerifyServerResponse(response, nonce))
            {
                std::string status = JsonGetString(response, "status");

                if (status == "valid")
                    finalResult = true;
            }
        }

        ShutdownCrypto();
        ShutdownHttp();

        return finalResult;
    }
}