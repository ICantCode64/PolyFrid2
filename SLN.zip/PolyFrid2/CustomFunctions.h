// So this code contains ALOT of borrowed stuff from fxkemoney
// Im sorry and yeah so uh yes. There are probably like 30-40 lines of my code here.

// Thanks!
#pragma once

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define _WINSOCKAPI_

#include <stdio.h>
#include "Windows.h"
#include "Lua.h";
#include "Libraries/Helpers.h"
#include "Libraries/Http.h"

// Borrowed typedefs from fxkemoney
typedef void(__fastcall* lua_pushcclosurek_t)(lua_State* L, lua_CFunction fn, const char* debugname, int nup, lua_CFunction cont);
typedef void(__fastcall* lua_pushstring_t)(lua_State* L, const char* s);
typedef void(__fastcall* lua_pushnil_t)(lua_State* L);
typedef void(__fastcall* lua_rawsetfield_t)(lua_State* L, int index, const char* k);
typedef const char* (__fastcall* lua_tolstring_t)(lua_State* L, int index, size_t* len);
typedef void(__fastcall* lua_pushvalue_t)(lua_State* L, int index);
typedef void(__fastcall* lua_xmove_t)(lua_State* from, lua_State* to, int n);

// my typedefs :yum:
typedef void (__fastcall* lua_setfield_t)(lua_State* L, int index, const char* k);
typedef void (__fastcall* lua_getfield_t)(lua_State* L, int index, const char* k);
typedef void(__fastcall* lua_settop_t)(lua_State* L, int idx);
typedef void(__fastcall* luaL_checktype_t)(lua_State* L, int idx, int t);
typedef unsigned __int64(__fastcall* lua_call_t)(lua_State* L, int nargs, int nresults);
typedef void(__fastcall* lua_insert_t)(lua_State* L, int idx);
typedef void(__fastcall* lua_pushboolean_t)(lua_State* L, int boolean);
typedef double(__fastcall* lua_tonumberx_t)(lua_State* L, int index, int* isnum);
typedef void(__fastcall* lua_pushnumber_t)(lua_State* L, double n);
typedef int(__fastcall* lua_error_t)(lua_State* L);
typedef bool(__fastcall* lua_iscfunction_t)(lua_State* L, int index, __int64 unused);
typedef bool(__fastcall* lua_isLfunction_t)(lua_State* L, int index, __int64 unused);
typedef int(__fastcall* lua_type_fn_t)(lua_State* L, int index);

lua_pushstring_t p_lua_pushstring = nullptr;
lua_pushcclosurek_t p_lua_pushcclosurek = nullptr;
lua_rawsetfield_t p_lua_rawsetfield = nullptr;
lua_pushnil_t p_lua_pushnil = nullptr;
lua_tolstring_t p_lua_tolstring = nullptr;
lua_pushvalue_t p_lua_pushvalue = nullptr;
lua_xmove_t p_lua_xmove = nullptr;

lua_setfield_t p_lua_setfield = nullptr;
lua_getfield_t p_lua_getfield = nullptr;
lua_settop_t p_lua_settop = nullptr;
luaL_checktype_t p_luaL_checktype = nullptr;
lua_call_t p_lua_call = nullptr;
lua_insert_t p_lua_insert = nullptr;
lua_pushboolean_t p_lua_pushboolean = nullptr;
lua_tonumberx_t p_lua_tonumber = nullptr;
lua_pushnumber_t p_lua_pushnumber = nullptr;
lua_error_t p_lua_error = nullptr;
lua_iscfunction_t p_lua_iscfunction = nullptr;
lua_isLfunction_t p_lua_isLfunction = nullptr;
lua_type_fn_t p_lua_type_x = nullptr;

#define p_lua_pop(L,n) p_lua_settop(L, -(n)-1)
#define p_lua_upvalueindex(i) (LUA_REGISTRYINDEX - (i))

lua_State* g_scriptThread = nullptr;

static int l_loadstring(lua_State* L)
{
    size_t len = 0;
    const char* source = p_lua_tolstring(L, 1, &len);
    if (!source) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected string");
        return 2;
    }

    int status = CompileString(L, source);

    if (status != 0)
    {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "compile/load failed");
        Log("[-] Compile failed");
        return 1;
    }

    return 1;
}

static int p_lua_newtable(lua_State* L)
{
    int status = CompileString(L, "return {}");

    if (status == 0)
    {
        fp_lua_pcall(L, 0, 1, 0);
        return 1;
    } else {
        Log("[-] Compile failed");
    }

    p_lua_pushnil(L);
    return 1;
}

static int l_getgenv(lua_State* L) {
    p_lua_pushvalue(g_scriptThread, LUA_GLOBALSINDEX);
    if (g_scriptThread != L && p_lua_xmove)
        p_lua_xmove(g_scriptThread, L, 1);
    return 1;
}

static int l_getreg(lua_State* L) {
    p_lua_pushvalue(L, LUA_REGISTRYINDEX);
    return 1;
}

static int l_getpenv(lua_State* L)
{
    p_lua_getfield(L, LUA_REGISTRYINDEX, "PENV");
    return 1;
}

void InitGenv(lua_State* L) {
    // Borrowed it from fxkemoney
    g_scriptThread = L;
    Log("[+] Lua state: 0x%p", g_scriptThread);
}

int l_rconsoleprint(lua_State* L) {
    size_t len = 0;
    const char* message = p_lua_tolstring(L, 1, &len);
    if (!message) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected string");
        return 2;
    }

    Log(message);

    return 1;
}

int l_rconsolename(lua_State* L) {
    size_t len = 0;
    const char* name = p_lua_tolstring(L, 1, &len);
    if (!name) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected string");
        return 2;
    }

    SetConsoleTitleA(name);

    return 1;
}

static int l_rconsoleinput(lua_State* L)
{
    std::string line = Input("> ");

    p_lua_pushstring(L, line.c_str());
    return 1;
}

static int l_setclipboard(lua_State* L) {
    size_t len = 0;
    const char* text = p_lua_tolstring(L, 1, &len);
    if (!text) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected string");
        return 2;
    }

    int wlen = MultiByteToWideChar(CP_UTF8, 0, text, -1, nullptr, 0);

    HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, wlen * sizeof(wchar_t));

    if (!hMem)
    {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "GlobalAlloc failed");
        return 2;
    }

    wchar_t* wdata = (wchar_t*)GlobalLock(hMem);
    MultiByteToWideChar(CP_UTF8, 0, text, -1, wdata, wlen);

    GlobalUnlock(hMem);

    if (!OpenClipboard(nullptr))
    {
        GlobalFree(hMem);

        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to open clipboard");
        return 2;
    }

    EmptyClipboard();
    SetClipboardData(CF_UNICODETEXT, hMem);

    CloseClipboard();

    p_lua_pushnil(L);
    return 1;
}

static int l_identifyexecutor(lua_State* L) {
    p_lua_pushstring(L, "polyfrid");
    return 1;
}

static int l_httpget(lua_State* L)
{
    size_t len = 0;

    const char* url =
        p_lua_tolstring(L, 1, &len);

    if (!url)
    {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected string");
        return 2;
    }

    std::wstring host;
    std::wstring path;
    bool https;

    if (!ParseURL(url, host, path, https))
    {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "invalid url");
        return 2;
    }

    std::string response =
        HTTPGET(
            host.c_str(),
            path.c_str());

    p_lua_pushstring(L, response.c_str());

    return 1;
}

static int l_readfile(lua_State* L) {
    size_t len = 0;
    const char* path = p_lua_tolstring(L, 1, &len);
    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected string");
        return 2;
    }

    FILE* f = NULL;
    errno_t err = fopen_s(&f, path, "rb");

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);

    if (size < 0) {
        fclose(f);

        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to get file size");
        return 2;
    }

    char* buffer = (char*)malloc((size_t)size + 1);
    if (!buffer) {
        fclose(f);

        p_lua_pushnil(L);
        p_lua_pushstring(L, "out of memory");
        return 2;
    }

    size_t read = fread(buffer, 1, (size_t)size, f);
    fclose(f);

    if (read != (size_t)size) {
        free(buffer);

        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to read file");
        return 2;
    }

    buffer[size] = '\0';

    p_lua_pushstring(L, buffer);

    free(buffer);
    return 1;
}

static int l_writefile(lua_State* L) {
    size_t path_len = 0;
    const char* path = p_lua_tolstring(L, 1, &path_len);
    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected path string");
        return 2;
    }

    size_t data_len = 0;
    const char* data = p_lua_tolstring(L, 2, &data_len);
    if (!data) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected data string");
        return 2;
    }

    FILE* f = NULL;
    errno_t err = fopen_s(&f, path, "wb");

    if (err != 0 || !f) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to open file");
        return 2;
    }

    size_t written = fwrite(data, 1, data_len, f);
    fclose(f);

    if (written != data_len) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to write file");
        return 2;
    }

    p_lua_pushnil(L);
    return 1;
}

static int l_appendfile(lua_State* L) {
    size_t path_len = 0;
    const char* path = p_lua_tolstring(L, 1, &path_len);
    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected path string");
        return 2;
    }

    size_t data_len = 0;
    const char* data = p_lua_tolstring(L, 2, &data_len);
    if (!data) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected data string");
        return 2;
    }

    FILE* f = NULL;
    errno_t err = fopen_s(&f, path, "ab");

    if (err != 0 || !f) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to open file");
        return 2;
    }

    size_t written = fwrite(data, 1, data_len, f);
    fclose(f);

    if (written != data_len) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to append file");
        return 2;
    }

    p_lua_pushboolean(L, 1);
    return 1;
}

static int l_listfiles(lua_State* L) {
    size_t len = 0;
    const char* folder = p_lua_tolstring(L, 1, &len);

    if (!folder) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected folder string");
        return 2;
    }

    char search[MAX_PATH];
    snprintf(search, sizeof(search), "%s\\*", folder);

    WIN32_FIND_DATAA data;
    HANDLE hFind = FindFirstFileA(search, &data);

    if (hFind == INVALID_HANDLE_VALUE) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to open folder");
        return 2;
    }

    p_lua_newtable(L);

    int index = 1;
    char key[32];

    do {
        const char* name = data.cFileName;

        if (strcmp(name, ".") == 0 || strcmp(name, "..") == 0)
            continue;

        snprintf(key, sizeof(key), "%d", index++);

        p_lua_pushstring(L, name);
        p_lua_setfield(L, -2, key);

    } while (FindNextFileA(hFind, &data));

    FindClose(hFind);

    return 1;
}

static int l_isfile(lua_State* L) {
    size_t len = 0;
    const char* path = p_lua_tolstring(L, 1, &len);

    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected path string");
        return 2;
    }

    DWORD attr = GetFileAttributesA(path);

    if (attr == INVALID_FILE_ATTRIBUTES) {
        p_lua_pushboolean(L, 0);
        return 1;
    }

    p_lua_pushboolean(L, !(attr & FILE_ATTRIBUTE_DIRECTORY));
    return 1;
}

static int l_isfolder(lua_State* L) {
    size_t len = 0;
    const char* path = p_lua_tolstring(L, 1, &len);

    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected path string");
        return 2;
    }

    DWORD attr = GetFileAttributesA(path);

    if (attr == INVALID_FILE_ATTRIBUTES) {
        p_lua_pushboolean(L, 0);
        return 1;
    }

    p_lua_pushboolean(L, (attr & FILE_ATTRIBUTE_DIRECTORY) != 0);
    return 1;
}

static int l_makefolder(lua_State* L) {
    size_t len = 0;
    const char* path = p_lua_tolstring(L, 1, &len);

    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected folder path");
        return 2;
    }

    if (!CreateDirectoryA(path, NULL)) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to create folder");
        return 2;
    }

    p_lua_pushboolean(L, 1);
    return 1;
}

static int l_delfolder(lua_State* L) {
    size_t len = 0;
    const char* path = p_lua_tolstring(L, 1, &len);

    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected folder path");
        return 2;
    }

    if (!RemoveDirectoryA(path)) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to delete folder");
        return 2;
    }

    p_lua_pushboolean(L, 1);
    return 1;
}

static int l_delfile(lua_State* L) {
    size_t len = 0;
    const char* path = p_lua_tolstring(L, 1, &len);

    if (!path) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected file path");
        return 2;
    }

    if (!DeleteFileA(path)) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to delete file");
        return 2;
    }

    p_lua_pushboolean(L, 1);
    return 1;
}

static int l_messagebox(lua_State* L) {
    size_t text_len = 0;
    const char* text = p_lua_tolstring(L, 1, &text_len);

    if (!text) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected text string");
        return 2;
    }

    size_t caption_len = 0;
    const char* caption = p_lua_tolstring(L, 2, &caption_len);

    if (!caption) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected caption string");
        return 2;
    }

    int isnum = 0;
    double n = p_lua_tonumber(L, 3, &isnum);

    if (!isnum) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected style number");
        return 2;
    }

    int style = (int)n;

    UINT flags = MB_OK;

    switch (style) {
    case 0:
        flags = MB_OK;
        break;
    case 1:
        flags = MB_OKCANCEL;
        break;
    case 2:
        flags = MB_ABORTRETRYIGNORE;
        break;
    case 3:
        flags = MB_YESNOCANCEL;
        break;
    case 4:
        flags = MB_YESNO;
        break;
    case 5:
        flags = MB_RETRYCANCEL;
        break;
    case 6:
        flags = MB_CANCELTRYCONTINUE;
        break;
    default:
        flags = MB_OK;
        break;
    }

    int result = MessageBoxA(NULL, text, caption, flags);

    p_lua_pushnumber(L, result);
    return 1;
}

static int l_mouse1press(lua_State* L) {
    send_mouse(MOUSEEVENTF_LEFTDOWN);
    return 0;
}

static int l_mouse1release(lua_State* L) {
    send_mouse(MOUSEEVENTF_LEFTUP);
    return 0;
}

static int l_mouse1click(lua_State* L) {
    send_mouse(MOUSEEVENTF_LEFTDOWN);
    send_mouse(MOUSEEVENTF_LEFTUP);
    return 0;
}

static int l_mouse2press(lua_State* L) {
    send_mouse(MOUSEEVENTF_RIGHTDOWN);
    return 0;
}

static int l_mouse2release(lua_State* L) {
    send_mouse(MOUSEEVENTF_RIGHTUP);
    return 0;
}

static int l_mouse2click(lua_State* L) {
    send_mouse(MOUSEEVENTF_RIGHTDOWN);
    send_mouse(MOUSEEVENTF_RIGHTUP);
    return 0;
}

static int l_mousescroll(lua_State* L) {
    int isnum = 0;
    int amount = (int)p_lua_tonumber(L, 1, &isnum);

    if (!isnum) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected number");
        return 2;
    }

    INPUT input;
    ZeroMemory(&input, sizeof(input));

    input.type = INPUT_MOUSE;
    input.mi.dwFlags = MOUSEEVENTF_WHEEL;
    input.mi.mouseData = amount;

    SendInput(1, &input, sizeof(INPUT));

    return 0;
}

static int l_mousemoverel(lua_State* L) {
    int isnum1 = 0;
    int isnum2 = 0;

    int x = (int)p_lua_tonumber(L, 1, &isnum1);
    int y = (int)p_lua_tonumber(L, 2, &isnum2);

    if (!isnum1 || !isnum2) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected x and y numbers");
        return 2;
    }

    INPUT input;
    ZeroMemory(&input, sizeof(input));

    input.type = INPUT_MOUSE;
    input.mi.dwFlags = MOUSEEVENTF_MOVE;
    input.mi.dx = x;
    input.mi.dy = y;

    SendInput(1, &input, sizeof(INPUT));

    return 0;
}

static int l_mousemoveabs(lua_State* L) {
    int isnum1 = 0;
    int isnum2 = 0;

    int x = (int)p_lua_tonumber(L, 1, &isnum1);
    int y = (int)p_lua_tonumber(L, 2, &isnum2);

    if (!isnum1 || !isnum2) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected x and y numbers");
        return 2;
    }

    HWND roblox = FindWindowA(NULL, "Roblox");

    if (!roblox) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "roblox window not found");
        return 2;
    }

    RECT rect;
    GetWindowRect(roblox, &rect);

    int absX = rect.left + x;
    int absY = rect.top + y;

    SetCursorPos(absX, absY);

    return 0;
}

static int l_keypress(lua_State* L) {
    int isnum = 0;

    int key = (int)p_lua_tonumber(L, 1, &isnum);

    if (!isnum) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected keycode number");
        return 2;
    }

    send_key((WORD)key, 0);

    return 0;
}

static int l_keyrelease(lua_State* L) {
    int isnum = 0;

    int key = (int)p_lua_tonumber(L, 1, &isnum);

    if (!isnum) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected keycode number");
        return 2;
    }

    send_key((WORD)key, KEYEVENTF_KEYUP);

    return 0;
}

static int l_ispolyactive(lua_State* L) {
    HWND foreground = GetForegroundWindow();

    if (!foreground) {
        p_lua_pushboolean(L, 0);
        return 1;
    }

    char title[256];
    GetWindowTextA(foreground, title, sizeof(title));

    if (strstr(title, "Polytoria")) {
        p_lua_pushboolean(L, 1);
    }
    else {
        p_lua_pushboolean(L, 0);
    }

    return 1;
}

static int l_getclipboard(lua_State* L) {
    if (!OpenClipboard(NULL)) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to open clipboard");
        return 2;
    }

    HANDLE handle = GetClipboardData(CF_TEXT);

    if (!handle) {
        CloseClipboard();

        p_lua_pushnil(L);
        p_lua_pushstring(L, "clipboard has no text");
        return 2;
    }

    char* text = (char*)GlobalLock(handle);

    if (!text) {
        CloseClipboard();

        p_lua_pushnil(L);
        p_lua_pushstring(L, "failed to lock clipboard");
        return 2;
    }

    p_lua_pushstring(L, text);

    GlobalUnlock(handle);
    CloseClipboard();

    return 1;
}

static int cclosure_handler(lua_State* L) {
    int nargs = fp_lua_gettop(L);

    p_lua_pushvalue(L, p_lua_upvalueindex(1));

    if (!p_lua_isLfunction(L, -1, 0) && !p_lua_iscfunction(L, -1, 0)) {
        p_lua_pushstring(L, "newcclosure upvalue is not function");
        return p_lua_error(L);
    }

    p_lua_insert(L, 1);

    int status = fp_lua_pcall(L, nargs, LUA_MULTRET, 0);
    if (status != 0)
        return p_lua_error(L);

    return fp_lua_gettop(L);
}

static int l_newcclosure(lua_State* L) {
    if (!p_lua_isLfunction(L, 1, 0) && !p_lua_iscfunction(L, 1, 0)) {
        p_lua_pushnil(L);
        p_lua_pushstring(L, "expected function");
        return 2;
    }

    p_lua_pushvalue(L, 1);

    p_lua_pushcclosurek(
        L,
        cclosure_handler,
        "newcclosure",
        1,
        nullptr
    );

    return 1;
}

static int l_rawset(lua_State* L) {
    Log("rawset called");

    size_t len = 0;
    const char* key = p_lua_tolstring(L, 2, &len);

    Log("[rawset] key = %s", key);

    p_lua_pushvalue(L, 3);
    p_lua_rawsetfield(L, 1, key);

    p_lua_pushvalue(L, 1);
    return 1;
}

void InitPenv(lua_State* L)
{
    p_lua_newtable(L);
    p_lua_setfield(L, LUA_REGISTRYINDEX, "PENV");
}

void InitiateFuncs() {
    HMODULE hMod = GetModuleHandleA("Luau.VM.dll");
    if (!hMod)
        return;

    p_lua_pushcclosurek = (lua_pushcclosurek_t)GetProcAddress(hMod, "lua_pushcclosurek");
    p_lua_rawsetfield = (lua_rawsetfield_t)GetProcAddress(hMod, "lua_rawsetfield");
    p_lua_pushstring = (lua_pushstring_t)GetProcAddress(hMod, "lua_pushstring");
    p_lua_pushnil = (lua_pushnil_t)GetProcAddress(hMod, "lua_pushnil");
    p_lua_tolstring = (lua_tolstring_t)GetProcAddress(hMod, "lua_tolstring");
    p_lua_pushvalue = (lua_pushvalue_t)GetProcAddress(hMod, "lua_pushvalue");
    p_lua_xmove = (lua_xmove_t)GetProcAddress(hMod, "lua_xmove");

    p_lua_setfield = (lua_setfield_t)GetProcAddress(hMod, "lua_setfield");
    p_lua_getfield = (lua_getfield_t)GetProcAddress(hMod, "lua_getfield");
    p_lua_settop = (lua_settop_t)GetProcAddress(hMod, "lua_settop");
    p_luaL_checktype = (luaL_checktype_t)GetProcAddress(hMod, "luaL_checktype");
    p_lua_call = (lua_call_t)GetProcAddress(hMod, "lua_call");
    p_lua_insert = (lua_insert_t)GetProcAddress(hMod, "lua_insert");
    p_lua_pushboolean = (lua_pushboolean_t)GetProcAddress(hMod, "lua_pushboolean");
    p_lua_tonumber = (lua_tonumberx_t)GetProcAddress(hMod, "lua_tonumberx");
    p_lua_pushnumber = (lua_pushnumber_t)GetProcAddress(hMod, "lua_pushnumber");
    p_lua_error = (lua_error_t)GetProcAddress(hMod, "lua_error");
    p_lua_isLfunction = (lua_isLfunction_t)GetProcAddress(hMod, "lua_isLfunction");
    p_lua_iscfunction = (lua_iscfunction_t)GetProcAddress(hMod, "lua_iscfunction");
    p_lua_type_x = (lua_type_fn_t)GetProcAddress(hMod, "lua_type");

    InitHttp();
}

void RegisterFunction(lua_State* L, const char* name, lua_CFunction func) {
    // Function by fxkemoney
    p_lua_pushcclosurek(L, func, name, 0, nullptr);
    p_lua_rawsetfield(L, LUA_GLOBALSINDEX, name);

    std::string msg = "[+] Registered ";
    msg += name;

    Log(msg.c_str());
}

void RegAll(lua_State* L) {
    // Init
    InitGenv(L);
    InitPenv(L);


    // Mics
    RegisterFunction(L, "loadstring", l_loadstring);
    RegisterFunction(L, "getgenv", l_getgenv);
    RegisterFunction(L, "getreg", l_getreg);;
    RegisterFunction(L, "getpenv", l_getpenv);
    RegisterFunction(L, "setclipboard", l_setclipboard);
    RegisterFunction(L, "getclipboard", l_getclipboard);
    RegisterFunction(L, "identifyexecutor", l_identifyexecutor);
    RegisterFunction(L, "httpget", l_httpget);
    RegisterFunction(L, "messagebox", l_messagebox);
    

    // Files!
    RegisterFunction(L, "readfile", l_readfile);
    RegisterFunction(L, "writefile", l_writefile);
    RegisterFunction(L, "appendfile", l_appendfile);
    RegisterFunction(L, "listfiles", l_listfiles);
    RegisterFunction(L, "isfile", l_isfile);
    RegisterFunction(L, "isfolder", l_isfolder);
    RegisterFunction(L, "makefolder", l_makefolder);
    RegisterFunction(L, "delfolder", l_delfile);
    RegisterFunction(L, "delfile", l_delfile);


    // Console!
    RegisterFunction(L, "rconsoleprint", l_rconsoleprint);
    RegisterFunction(L, "rconsoleinput", l_rconsoleinput);
    RegisterFunction(L, "rconsolename", l_rconsolename);


    // Input/Output
    RegisterFunction(L, "ispolyactive", l_ispolyactive);
    RegisterFunction(L, "mouse1click", l_mouse1click);
    RegisterFunction(L, "mouse1press", l_mouse1press);
    RegisterFunction(L, "mouse1release", l_mouse1release);
    RegisterFunction(L, "mouse2click", l_mouse2click);
    RegisterFunction(L, "mouse2press", l_mouse2press);
    RegisterFunction(L, "mouse2release", l_mouse2release);
    RegisterFunction(L, "mousescroll", l_mousescroll);
    RegisterFunction(L, "mousemoverel", l_mousemoverel);
    RegisterFunction(L, "mousemoveabs", l_mousemoveabs);
    RegisterFunction(L, "keypress", l_keypress);
    RegisterFunction(L, "keyrelease", l_keyrelease);


    // Hooking?
    RegisterFunction(L, "rawset", l_rawset);
    RegisterFunction(L, "newcclosure", l_newcclosure);
}