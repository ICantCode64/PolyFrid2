﻿#include "MinHook.h"
#include <Windows.h>
#include "Lua.h"
#include <iostream>
#include <mutex>
#include <queue>
#include "CustomFunctions.h"
#include "Libraries/Helpers.h"
#include "Keysystem.h"

using lua_type_t = int(__fastcall*)(lua_State* L, int index);
lua_type_t fp_lua_type = nullptr;

lua_State* g_L = nullptr;

std::queue<std::string> g_queue;
std::mutex g_mutex;

std::string gazan = "https://gazan.rf.gd/";

DWORD WINAPI KeyCheckThread(LPVOID lpParam) {
    while (true) {
        std::string key = ReadRegistryString(
            HKEY_CURRENT_USER,
            "Software\\PolyFrid\\License",
            "Key"
        );

        std::string name = ReadRegistryString(
            HKEY_CURRENT_USER,
            "Software\\PolyFrid\\License",
            "Name"
        );

        bool valid = KeySystem::verify(name, key);

        if (!valid) {
            TerminateProcess(GetCurrentProcess(), 1);
        }

        Sleep(1500);
    }

    return 0;
}

DWORD WINAPI Pipe(LPVOID lpParam)
{
    InitConsole();

    Log(R"(______     _      ______    _     _ 
| ___ \   | |     |  ___|  (_)   | |
| |_/ /__ | |_   _| |_ _ __ _  __| |
|  __/ _ \| | | | |  _| '__| |/ _` |
| | | (_) | | |_| | | | |  | | (_| |
\_|  \___/|_|\__, \_| |_|  |_|\__,_|
              __/ |                 
             |___/                  
By breadbars (discord: .breadbars)
)");

    std::string key = ReadRegistryString(
        HKEY_CURRENT_USER,
        "Software\\PolyFrid\\License",
        "Key"
    );

    std::string name = ReadRegistryString(
        HKEY_CURRENT_USER,
        "Software\\PolyFrid\\License",
        "Name"
    );

    if (!valid) {
        Log("[-] Invalid PolyFrid key! Please get one from the creator!");
        return 0;
    }

    uintptr_t known = (uintptr_t)g_L;

    for (int off = 0; off < 0x100; off += 8)
    {
        void* v = *(void**)(known + off);
        LogEx(false, "+%02X = %p\n", off, v);
    }

    InitiateFuncs();
    Log("[+] Attached!");
    RegAll(g_L);

    CreateThread(nullptr, 0, KeyCheckThread, nullptr, 0, nullptr);

    while (true)
    {
        HANDLE hPipe = CreateNamedPipeA(
            R"(\\.\pipe\PolyFrid2)",
            PIPE_ACCESS_INBOUND,
            PIPE_TYPE_MESSAGE | PIPE_READMODE_MESSAGE | PIPE_WAIT,
            PIPE_UNLIMITED_INSTANCES,
            0,
            0,
            0,
            NULL
        );

        if (hPipe == INVALID_HANDLE_VALUE)
        {
            return 1;
        }

        BOOL connected = ConnectNamedPipe(hPipe, NULL) ?
            TRUE : (GetLastError() == ERROR_PIPE_CONNECTED);

        if (connected)
        {
            char buffer[65536];
            DWORD bytesRead = 0;

            while (true)
            {
                BOOL result = ReadFile(
                    hPipe,
                    buffer,
                    sizeof(buffer) - 1,
                    &bytesRead,
                    NULL
                );

                if (!result || bytesRead == 0)
                {
                    break;
                }

                buffer[bytesRead] = '\0';
                std::lock_guard<std::mutex> lock(g_mutex);
                g_queue.push(buffer);
            }
        }

        CloseHandle(hPipe);
    }

    return 0;
}

void ProcessQueue()
{
    if (g_queue.empty() || !g_L)
        return;

    std::string script = g_queue.front();
    g_queue.pop();

    Exec(g_L, script.c_str());
}

int __fastcall hk_lua_type(lua_State* L, int index)
{
    ProcessQueue();
    if (!g_L && L && IsValidMemory((uintptr_t)L)) {
        int top = fp_lua_gettop(L);
        if (top >= 0 && top < 10000) {
            g_L = L;
            CreateThread(nullptr, 0, Pipe, nullptr, 0, nullptr);
        }
    }
    if (g_L) {
        ResetConsoleColor();
    }
    return fp_lua_type(L, index);
}

void LoadCompiler() {
    HMODULE h = LoadLibraryA("Luau.Compiler.dll");

    if (!h)
    {
        MessageBoxA(0, "Failed to load compiler", "error", MB_OK);
        return;
    }
}

DWORD WINAPI InitThread(LPVOID lpParam)
{
    if (MH_Initialize() != MH_OK)
        return 0;

    HMODULE hMod = GetModuleHandleA("Luau.VM.dll");
    if (!hMod)
        return 0;

    void* target = GetProcAddress(hMod, "lua_type");
    if (!target)
        return 0;

    fp_lua_gettop = (lua_gettop_t)GetProcAddress(hMod, "lua_gettop");

    MH_CreateHook(
        target,
        &hk_lua_type,
        reinterpret_cast<LPVOID*>(&fp_lua_type)
    );

    MH_EnableHook(target);

    LoadCompiler();
    GetFunctions();

    return 0;
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);
        CreateThread(nullptr, 0, InitThread, hModule, 0, nullptr);
    }
    return TRUE;
}